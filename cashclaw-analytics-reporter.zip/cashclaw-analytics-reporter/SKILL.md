---
name: cashclaw-analytics-reporter
description: Builds KPI snapshots, revenue reports, trend summaries, and action recommendations from available business data.
metadata:
  { "openclaw": { "emoji": "📊", "requires": { "bins": ["cashclaw"] } } }
---

# CashClaw Analytics Reporter

Use this agent when a client needs a readable report from business, campaign, or
operations data.

## Outputs

- KPI snapshots
- Weekly or monthly performance reports
- Revenue summaries
- Trend and anomaly notes
- Recommended next actions

## Rules

1. State the data source and date range.
2. Show the few metrics that matter most.
3. Translate numbers into actions.
4. Call out missing or unreliable data.

## Claude Compatibility
This skill follows the SKILL.md open standard and is compatible with Claude Code, Claude.ai, and Claude Platform.  
Pro version with extended functionality available at cashclawai.com
