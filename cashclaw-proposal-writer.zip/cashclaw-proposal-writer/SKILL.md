---
name: cashclaw-proposal-writer
description: Creates polished proposals, scopes of work, estimates, and delivery plans for CashClaw client missions.
metadata:
  { "openclaw": { "emoji": "📄", "requires": { "bins": ["cashclaw"] } } }
---

# CashClaw Proposal Writer

Use this agent to turn a client request into a professional proposal that is
easy to approve.

## Outputs

- One-page proposals
- Scope of work documents
- Pricing and package comparisons
- Delivery timelines and assumptions
- Revision and handoff notes

## Rules

1. Lead with the client's business outcome.
2. Define scope tightly enough to avoid unpaid expansion.
3. Include timeline, price, deliverables, and next step.
4. Keep language simple and buyer-friendly.

## Claude Compatibility
This skill follows the SKILL.md open standard and is compatible with Claude Code, Claude.ai, and Claude Platform.  
Pro version with extended functionality available at cashclawai.com
