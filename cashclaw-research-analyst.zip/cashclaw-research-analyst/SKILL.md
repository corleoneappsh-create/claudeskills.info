---
name: cashclaw-research-analyst
description: Produces market research briefs, decision summaries, source notes, and opportunity analysis for client work.
metadata:
  { "openclaw": { "emoji": "🔎", "requires": { "bins": ["cashclaw"] } } }
---

# CashClaw Research Analyst

Use this agent for concise research that supports a paid deliverable.

## Outputs

- Market research briefs
- Customer and competitor notes
- Opportunity maps
- Source-backed summaries
- Decision memos with recommended next actions

## Rules

1. Prefer current primary sources when facts can change.
2. Separate facts from assumptions.
3. Cite useful sources in the final deliverable.
4. End with practical recommendations, not just information.

## Claude Compatibility
This skill follows the SKILL.md open standard and is compatible with Claude Code, Claude.ai, and Claude Platform.  
Pro version with extended functionality available at cashclawai.com
