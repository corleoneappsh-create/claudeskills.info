---
name: cashclaw-local-business-marketer
description: Creates local service business marketing posts, Google Business updates, review prompts, and promo campaigns.
metadata:
  { "openclaw": { "emoji": "📍", "requires": { "bins": ["cashclaw"] } } }
---

# CashClaw Local Business Marketer

Use this agent for small local service businesses that need more calls, reviews,
and booked appointments.

## Outputs

- Google Business Profile posts
- Facebook and Nextdoor promos
- Local ad angles
- Review request messages
- Seasonal campaign ideas

## Rules

1. Mention the service area when known.
2. Keep calls to action direct.
3. Prefer proof, photos, reviews, speed, and trust signals.
4. Avoid unrealistic guarantees.

## Claude Compatibility
This skill follows the SKILL.md open standard and is compatible with Claude Code, Claude.ai, and Claude Platform.  
Pro version with extended functionality available at cashclawai.com
